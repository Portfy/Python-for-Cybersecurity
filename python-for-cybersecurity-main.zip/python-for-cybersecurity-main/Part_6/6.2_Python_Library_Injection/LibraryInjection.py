import safelibrary

print("Hello World")